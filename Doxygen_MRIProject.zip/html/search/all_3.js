var searchData=
[
  ['database',['database',['../classdatabase.html',1,'']]],
  ['database_2ejava',['database.java',['../database_8java.html',1,'']]],
  ['db_5fname',['db_name',['../classdatabase.html#af19eabcc17a3bee4499cff399440b863',1,'database']]],
  ['deneme2',['deneme2',['../classdeneme2.html',1,'']]],
  ['deneme2_2ejava',['deneme2.java',['../deneme2_8java.html',1,'']]]
];
