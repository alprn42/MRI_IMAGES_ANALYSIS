var searchData=
[
  ['db_5fname',['db_name',['../classdatabase.html#af19eabcc17a3bee4499cff399440b863',1,'database']]]
];
