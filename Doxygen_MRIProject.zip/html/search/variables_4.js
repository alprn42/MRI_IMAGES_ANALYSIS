var searchData=
[
  ['gui',['gui',['../classdeneme2.html#a421ad442fb2fdd7b6e1452a674efcce1',1,'deneme2']]]
];
