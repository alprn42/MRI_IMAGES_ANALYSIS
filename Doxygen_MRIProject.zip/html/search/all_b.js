var searchData=
[
  ['resize',['resize',['../class_image_panel.html#a5bb6a63d9c1e1c90fb106e6cdb4494c2',1,'ImagePanel']]],
  ['run',['run',['../classdeneme2.html#ae39916daa0de790e1f147c0aed79c594',1,'deneme2.run()'],['../class_selected_area.html#a9c8f3bac180538729af01413ab6b39cb',1,'SelectedArea.run()']]]
];
