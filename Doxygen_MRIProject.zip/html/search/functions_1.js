var searchData=
[
  ['imagepanel',['ImagePanel',['../class_image_panel.html#a6bd2fffaae419c7d1055dd568533c7a5',1,'ImagePanel']]],
  ['initialize',['initialize',['../class_selected_area.html#a6201ddab7018fa2bd81f153ac81c473a',1,'SelectedArea']]]
];
