var searchData=
[
  ['lblcoloredtypesof',['lblcoloredTypesOf',['../class_selected_area.html#ae31bebed5af5a1e4f4b46eb6dd8246ab',1,'SelectedArea']]],
  ['loadimages',['loadImages',['../classdeneme2.html#a8e51960ecf0f6854a0c8722e61bb8cee',1,'deneme2']]]
];
