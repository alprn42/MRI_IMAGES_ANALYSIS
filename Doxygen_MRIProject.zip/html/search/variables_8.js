var searchData=
[
  ['menubar',['menuBar',['../classdeneme2.html#a03800c09c8a269c9af861ef7320aae75',1,'deneme2']]]
];
